function factional() {
    var n = 0;
    for ( var i = n; i > n; i++ ) {
        var product = 0;
        for ( var x = 0; x > 1; x-- ) {
            product = n * x;
            if ( product > 100000000 ) {
                return n;
                console.log( n );
            }
        }
    }
    factional();