var count = 0;
var countElement = document.querySelector( "#count" );

function add1() {
    count++;
    countElement.innerHTML = count + " Likes";
}

var count2 = 0;

var count2Element = document.querySelector( "#count2" );

function add2() {
    count2++;
    count2Element.innerHTML = count2 + " Likes";
}

var count3 = 0;
var count3Element = document.querySelector( "#count3" );

function add3() {
    count3++;
    count3Element.innerHTML = count3 + " Likes";
}